
from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

class AgentRequest(BaseModel):
    user_input: str
    ui_context: str

@app.post("/ask-agent")
def ask_agent(req: AgentRequest):
    # Mock AI response for demo (replace with Azure OpenAI later)
    return {
        "answer": f"In the {req.ui_context}, your input seems invalid. Please check the email format and try again."
    }
